# WarrantRoute — eight-page ACL manuscript skeleton

This folder contains the active ACL manuscript project. Upload its prepared ZIP archive to Overleaf and compile `main.tex` with **pdfLaTeX**.

## Upload in three steps

1. In Overleaf, choose **New Project → Upload Project**.
2. Upload `exports/warrant_route_acl2027_overleaf.zip`.
3. If Overleaf does not select it automatically, set `main.tex` as the main document and use pdfLaTeX.

## Included files

- `main.tex` — ACL review-mode entry point, result-placeholder commands, and abstract shell.
- `sections/paper.tex` — compact main paper with four blank results tables.
- `sections/appendix.tex` — protocol prompts and two blank supplementary tables.
- `custom.bib` — cited records with explicit archival and preprint status notes.
- `DATASET_PLAN.md` — the four candidate corpus lanes, verified source and processed-data audits, ethics caveats, access gates, and split constraints.
- `acl.sty` and `acl_natbib.bst` — unmodified official ACL files.
- `figures/` — publication PDF, editable SVG, and review PNG for the WarrantRoute framework figure.
- `manuscript-draft/` — the earlier full protocol draft and its bibliography.
- `exports/` — the prepared Overleaf upload ZIP and compiled manuscript preview.

## Current status

- The project has been compiled successfully with the framework figure and every citation resolved.
- The current build has no LaTeX errors, undefined citations, missing controls, or overfull boxes.
- The manuscript is intentionally marked **pre-data**. No empirical result, sample size, or effect is invented.
- The current build is **15 pages total**: the main paper occupies pages 1–8, references begin on page 9, and the skeleton appendix begins on page 10 and ends on page 15.
- The framework figure is included as a full-width vector PDF. Recompile and recount after inserting final values because page placement will change.

## Filling the manuscript

Search the project for the following three commands:

- `\fillin{...}` — replace the gray prose prompt with final text or a value.
- `\blankcell` — replace with a short result such as `0.81`.
- `\blankwide` — replace with a result and interval such as `0.81 [0.74, 0.87]`.

The four main-paper tables are deliberately blank:

1. study accounting;
2. role sensitivity by failure family;
3. held-out routing under matched expert time; and
4. downstream repair without collateral error.

The appendix contains blank reliability/calibration and transfer/ablation tables. Fill all tables from one frozen analysis export so denominators cannot drift between sections.

## Writing conventions

- Spell out the evaluator groups in prose: `researchers without specialist expertise`, `qualitative methods experts`, and `domain experts`.
- Do not introduce local acronyms for these groups. Narrow table headings use `Researchers`, `Methods experts`, and `Domain experts`.
- The manuscript narrative avoids dash punctuation and compressed compound labels. Preserve this style when adding results.
- Official publication titles in `custom.bib` remain unchanged even when the cited title itself contains a hyphen.

## Before submission

1. Confirm institutional, source or platform, model-processing, and rater-access authorization for every adopted corpus. Dreaddit and Cache2 (project alias: CaCHe) have provisional planned roles but remain governance-blocked. CaSiNo and AMI are source-only candidates until their transcript adapters, privacy reviews, experimental roles, and split constraints are approved and frozen.
2. Replace every `\fillin{...}`, `\blankcell`, and `\blankwide` field from a frozen analysis export.
3. Replace the prospective abstract with a results-bearing abstract.
4. Set `\predatadraftfalse` in `main.tex` to remove the draft warning.
5. Keep the main content within the applicable page limit; place secondary protocol detail, calibration, robustness checks, and ablations in the appendix.
6. Keep `\usepackage[review]{acl}` and anonymous author metadata for review. For a camera-ready version, follow the venue instructions and change the ACL option/author block only then.
7. Recheck the ACL 2027 call and template immediately before submission. This package uses the latest official generic *ACL style available on 25 August 2026; an ACL 2027 venue-specific update was not yet assumed.

## Template provenance

Official source: <https://github.com/acl-org/acl-style-files>

- ACL style commit: `d5adc823ff0f80f98c80405ca0ab66c68e684409`
- Commit date: 29 June 2026
- `acl.sty` and `acl_natbib.bst` are copied byte-for-byte and have not been modified.

The earlier full protocol draft is preserved in `manuscript-draft/`; the files at this folder's top level form the compact Overleaf submission project.
