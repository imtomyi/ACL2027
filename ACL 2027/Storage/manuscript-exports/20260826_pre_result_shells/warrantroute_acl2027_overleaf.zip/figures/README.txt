Place final paper figures in this directory and include them from main.tex or the section files.

Framework figure files:

- warrantroute_framework.pdf is the publication asset included by sections/paper.tex.
- warrantroute_framework.svg is the editable vector source.
- warrantroute_framework_preview.png is a high resolution review copy.
- archive/2026-08-26_original_complex/ preserves the previous, more detailed version in all three formats.

The framework figure describes the preregistered study design and does not report an empirical result.
