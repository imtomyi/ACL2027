# WarrantRoute — eight-page ACL manuscript skeleton

This folder contains the active ACL manuscript project. Upload its prepared ZIP archive to Overleaf and compile `main.tex` with **pdfLaTeX**.

## Upload in three steps

1. In Overleaf, choose **New Project → Upload Project**.
2. Upload `exports/warrant_route_acl2027_overleaf.zip`.
3. If Overleaf does not select it automatically, set `main.tex` as the main document and use pdfLaTeX.

## Included files

- `main.tex` — ACL review-mode entry point, result-placeholder commands, and abstract shell.
- `sections/paper.tex` — compact main paper, explicit RQ1--RQ2 framing, a standalone two-corpus dataset section and inventory table, and one primary result table and figure.
- `sections/appendix.tex` — full protocol, corpus inventories, and secondary reporting tables and figures.
- `custom.bib` — cited records with explicit archival and preprint status notes.
- `DATASET_PLAN.md` — the five candidate corpus lanes, verified source and processed-data audits, ethics caveats, access gates, and split constraints.
- `acl.sty` and `acl_natbib.bst` — unmodified official ACL files.
- `figures/` — publication PDFs, editable SVGs, and review PNGs for the WarrantRoute framework, the main role-by-flaw result template, and the appendix review-time template.
- `manuscript-draft/` — the earlier full protocol draft and its bibliography.
- `exports/` — the prepared Overleaf upload ZIP and compiled manuscript preview.

## Current status

- The project has been compiled successfully with the framework figure, two empty result templates, and every citation resolved.
- The current build has no LaTeX errors, undefined citations, missing controls, or overfull boxes.
- The manuscript is intentionally marked **pre-data**. It reports deterministic corpus-preparation statistics but no candidate-generation, human-rating, LLM-rating, routing, or other experimental result.
- The clean current build is **15 pages total**: the main paper occupies pages 1--6, references begin on page 7, and the appendix begins after the references on page 8 and ends on page 15. The two unused main-text pages are reserved for actual results and their interpretation. Recount after every rebuild because page placement changes as placeholders are filled.
- All three figures are included as full-width vector PDFs. The two result templates contain no marks or estimates. Recompile and recount after inserting final values because page placement will change.

## Filling the manuscript

Search the project for the following three commands:

- `\fillin{...}` — replace the gray prose prompt with final text or a value.
- `\blankcell` — replace with a short result such as `0.81`.
- `\blankwide` — replace with a result and interval such as `0.81 [0.74, 0.87]`.

The main paper reserves one role-by-flaw figure and one compact primary table for the two questions. RQ2 fields report pre-human LLM review on controlled variants; RQ1 fields report human routing only after the human study is complete. No third or fourth corpus row is reserved.

The appendix contains a secondary two-corpus human review-time histogram and blank artifact-quality, reliability, detailed routing, and corpus/feature-sensitivity tables. Fill each field only from its corresponding frozen analysis export so denominators cannot drift between sections.

## Non-negotiable data policy

Fictional, synthetic, demo, toy, and mock datasets and all experiments or
results derived from them are never manuscript-eligible. Do not place them in
the abstract, main text, appendix, tables, figures, compiled PDFs, or Overleaf
ZIP. Keep missing experimental results as explicit `\fillin`, `\blankcell`, or
`\blankwide` placeholders until the authorized frozen real-corpus analysis is
complete.

Before compiling or exporting, run:

```bash
python3 ../governance/scripts/check_manuscript_data_policy.py
```

The build or export must stop if this check fails.

## Writing conventions

- Spell out the evaluator groups in prose: `researchers without specialist expertise`, `qualitative methods experts`, and `domain experts`.
- Do not introduce local acronyms for these groups. Narrow table headings use `Researchers`, `Methods experts`, and `Domain experts`.
- The manuscript narrative avoids dash punctuation and compressed compound labels. Preserve this style when adding results.
- Official publication titles in `custom.bib` remain unchanged even when the cited title itself contains a hyphen.

## Before submission

1. Confirm institutional, source or platform, model-processing, and rater-access authorization for every adopted corpus. Dreaddit and Cache2 (project alias: CaCHe) have provisional roles but remain governance-blocked. KODIS has a private exploratory conversion but no manuscript role; CaSiNo and AMI remain source-inventory candidates until their adapters, privacy reviews, experimental roles, and split constraints are approved and frozen.
2. Run `python3 ../governance/scripts/check_manuscript_data_policy.py` and stop on any failure.
3. Replace every `\fillin{...}`, `\blankcell`, and `\blankwide` field from one authorized, frozen real-corpus analysis export.
4. Replace the prospective abstract with a results-bearing abstract.
5. Set `\predatadraftfalse` in `main.tex` to remove the draft warning.
6. Keep the main content within the applicable page limit; place secondary protocol detail, calibration, robustness checks, and ablations in the appendix.
7. Keep `\usepackage[review]{acl}` and anonymous author metadata for review. For a camera-ready version, follow the venue instructions and change the ACL option/author block only then.
8. Recheck the ACL 2027 call and template immediately before submission. This package uses the latest official generic *ACL style available on 25 August 2026; an ACL 2027 venue-specific update was not yet assumed.

## Template provenance

Official source: <https://github.com/acl-org/acl-style-files>

- ACL style commit: `d5adc823ff0f80f98c80405ca0ab66c68e684409`
- Commit date: 29 June 2026
- `acl.sty` and `acl_natbib.bst` are copied byte-for-byte and have not been modified.

The earlier full protocol draft is preserved in `manuscript-draft/`; the files at this folder's top level form the compact Overleaf submission project.
